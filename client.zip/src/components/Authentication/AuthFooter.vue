<template>
  <footer class="w-full px-4 py-4 relative z-10">
    <div
      class="backdrop-blur-md bg-white/10 border border-white/20 shadow-lg p-6 rounded-2xl max-w-3xl mx-auto"
    >
      <div class="text-center">
        <p class="text-gray-100">© 2025 Eco-Mist. All rights reserved.</p>
        <p class="text-xs text-white/60 mt-2 mb-2">
  <a href="https://policies.google.com/privacy" target="_blank" class="underline">Privacy Policy</a> and
  <a href="https://policies.google.com/terms" target="_blank" class="underline">Terms of Service</a> apply.
</p>
<p class="text-[10px] text-gray-50">
  This site is protected by reCAPTCHA and the Google
</p>


      </div>
    </div>
  </footer>
</template>
