<template>
  <svg xmlns="http://www.w3.org/2000/svg" class="w-8 h-8 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
    <path d="M3 3v18h18"/>
    <path d="M19 9l-5 5-4-4-3 3"/>
  </svg>
</template>

<script setup></script>
